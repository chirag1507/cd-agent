import { describe, it, expect, vi, beforeEach } from "vitest";
import fs from "fs-extra";

vi.mock("fs-extra", () => ({
  default: {
    copy: vi.fn(),
    ensureDir: vi.fn(),
    readdir: vi.fn().mockResolvedValue(["file1.md", "file2.md"]),
    pathExists: vi.fn().mockResolvedValue(false),
    readFile: vi.fn().mockResolvedValue(""),
    writeFile: vi.fn(),
    rename: vi.fn(),
    remove: vi.fn(),
  },
}));

import {
  generateToDirectory,
  checkForConflicts,
  getRequestedToolsOptions,
  VARIANTS,
  SCOPES,
} from "./cli-generator.js";

describe("generateToDirectory", () => {
  const MOCK_OUTPUT_PATH = "/mock/output/path";

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should generate command files to specified directory", async () => {
    const result = await generateToDirectory(MOCK_OUTPUT_PATH);

    expect(result.success).toBe(true);
    expect(result.filesGenerated).toBeGreaterThan(0);
  });

  it("should accept variant parameter and use it for generation", async () => {
    const result = await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
    );

    expect(result.success).toBe(true);
    expect(result.variant).toBe(VARIANTS.WITH_BEADS);
  });

  it("should copy files from source to output directory", async () => {
    await generateToDirectory(MOCK_OUTPUT_PATH, VARIANTS.WITH_BEADS);

    expect(fs.copy).toHaveBeenCalledWith(
      expect.stringContaining("downloads/with-beads"),
      MOCK_OUTPUT_PATH,
      expect.any(Object),
    );
  });

  it("should accept scope parameter and use project-level path", async () => {
    await generateToDirectory(undefined, VARIANTS.WITH_BEADS, SCOPES.PROJECT);

    expect(fs.copy).toHaveBeenCalledWith(
      expect.stringContaining("downloads/with-beads"),
      expect.stringContaining(".claude/commands"),
      expect.any(Object),
    );
  });

  it("should use user-level path when scope is user", async () => {
    await generateToDirectory(undefined, VARIANTS.WITH_BEADS, SCOPES.USER);

    expect(fs.copy).toHaveBeenCalledWith(
      expect.stringContaining("downloads/with-beads"),
      expect.stringContaining(".claude/commands"),
      expect.any(Object),
    );
  });

  it("should return actual count of files copied", async () => {
    const mockFiles = [
      "red.md",
      "green.md",
      "refactor.md",
      "cycle.md",
      "commit.md",
    ];
    vi.mocked(fs.readdir).mockResolvedValue(mockFiles as never);

    const result = await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
    );

    expect(result.filesGenerated).toBe(5);
  });

  it("should accept options object with skipTemplateInjection", async () => {
    const result = await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
      { skipTemplateInjection: true },
    );

    expect(result.success).toBe(true);
    expect(result.templateInjectionSkipped).toBe(true);
  });

  it("should append template from CLAUDE.md to copied command files", async () => {
    const templateContent = `<claude-commands-template>
## Project Context
This is a test project.
</claude-commands-template>`;
    const commandContent = `---
description: Test command
---

# Test Command`;

    vi.mocked(fs.pathExists).mockResolvedValue(true as never);
    vi.mocked(fs.readFile).mockImplementation(async (filePath: unknown) => {
      if (String(filePath).endsWith("CLAUDE.md")) {
        return templateContent;
      }
      return commandContent;
    });
    vi.mocked(fs.readdir).mockResolvedValue(["test.md"] as never);

    const result = await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
    );

    expect(result.templateInjected).toBe(true);
  });

  it("should fallback to AGENTS.md when CLAUDE.md does not exist", async () => {
    const templateContent = `<claude-commands-template>
## Agent Context
This is from AGENTS.md.
</claude-commands-template>`;
    const commandContent = `---
description: Test command
---

# Test Command`;

    vi.mocked(fs.pathExists).mockImplementation(async (filePath: unknown) => {
      return String(filePath).endsWith("AGENTS.md");
    });
    vi.mocked(fs.readFile).mockImplementation(async (filePath: unknown) => {
      if (String(filePath).endsWith("AGENTS.md")) {
        return templateContent;
      }
      return commandContent;
    });
    vi.mocked(fs.readdir).mockResolvedValue(["test.md"] as never);

    const result = await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
    );

    expect(result.templateInjected).toBe(true);
  });

  it("should write template content appended to command files", async () => {
    const templateContent = `<claude-commands-template>
## Injected Content
This should appear at the end.
</claude-commands-template>`;
    const commandContent = `# Original Command`;

    vi.mocked(fs.pathExists).mockResolvedValue(true as never);
    vi.mocked(fs.readFile).mockImplementation(async (filePath: unknown) => {
      if (String(filePath).endsWith("CLAUDE.md")) {
        return templateContent;
      }
      return commandContent;
    });
    vi.mocked(fs.readdir).mockResolvedValue(["test.md"] as never);

    await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
    );

    expect(fs.writeFile).toHaveBeenCalledWith(
      expect.stringContaining("test.md"),
      expect.stringContaining("## Injected Content"),
    );
  });

  it("should copy files directly to prefixed path when commandPrefix option is provided", async () => {
    vi.mocked(fs.readdir).mockResolvedValue(["red.md", "green.md"] as never);
    vi.mocked(fs.pathExists).mockResolvedValue(false as never);

    await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
      { commandPrefix: "my-" },
    );

    expect(fs.copy).toHaveBeenCalledWith(
      expect.stringContaining("red.md"),
      expect.stringContaining("my-red.md"),
    );
    expect(fs.copy).toHaveBeenCalledWith(
      expect.stringContaining("green.md"),
      expect.stringContaining("my-green.md"),
    );
  });

  it("should inject template to prefixed filenames when commandPrefix is used", async () => {
    const templateContent = `<claude-commands-template>
## Injected Content
</claude-commands-template>`;
    const commandContent = `# Original Command`;

    vi.mocked(fs.pathExists).mockResolvedValue(true as never);
    vi.mocked(fs.readFile).mockImplementation(async (filePath: unknown) => {
      if (String(filePath).endsWith("CLAUDE.md")) {
        return templateContent;
      }
      return commandContent;
    });
    vi.mocked(fs.readdir).mockResolvedValue(["red.md"] as never);

    await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
      { commandPrefix: "my-" },
    );

    expect(fs.writeFile).toHaveBeenCalledWith(
      expect.stringContaining("my-red.md"),
      expect.stringContaining("## Injected Content"),
    );
  });

  it("should only inject template to files matching commands filter", async () => {
    const templateContent = `<claude-commands-template commands="red,green">
## Only for TDD commands
</claude-commands-template>`;
    const commandContent = `# Original Command`;

    vi.mocked(fs.pathExists).mockResolvedValue(true as never);
    vi.mocked(fs.readFile).mockImplementation(async (filePath: unknown) => {
      if (String(filePath).endsWith("CLAUDE.md")) {
        return templateContent;
      }
      return commandContent;
    });
    vi.mocked(fs.readdir).mockResolvedValue([
      "red.md",
      "green.md",
      "commit.md",
    ] as never);

    await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
    );

    expect(fs.writeFile).toHaveBeenCalledTimes(2);
    expect(fs.writeFile).toHaveBeenCalledWith(
      expect.stringContaining("red.md"),
      expect.stringContaining("## Only for TDD commands"),
    );
    expect(fs.writeFile).toHaveBeenCalledWith(
      expect.stringContaining("green.md"),
      expect.stringContaining("## Only for TDD commands"),
    );
    expect(fs.writeFile).not.toHaveBeenCalledWith(
      expect.stringContaining("commit.md"),
      expect.anything(),
    );
  });

  it("should only copy selected commands when commands option is provided", async () => {
    vi.mocked(fs.readdir).mockResolvedValue([
      "red.md",
      "green.md",
      "commit.md",
      "refactor.md",
    ] as never);
    vi.mocked(fs.pathExists).mockResolvedValue(false as never);

    const result = await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
      {
        commands: ["red.md", "commit.md"],
      },
    );

    expect(result.filesGenerated).toBe(2);
    expect(fs.copy).toHaveBeenCalledTimes(2);
    expect(fs.copy).toHaveBeenCalledWith(
      expect.stringContaining("red.md"),
      expect.stringContaining("red.md"),
    );
    expect(fs.copy).toHaveBeenCalledWith(
      expect.stringContaining("commit.md"),
      expect.stringContaining("commit.md"),
    );
  });
});

describe("checkForConflicts", () => {
  const MOCK_OUTPUT_PATH = "/mock/output/path";

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should return conflict when destination file already exists with different content", async () => {
    const existingContent = "# My custom commit command";
    const newContent = "# Standard commit process";

    vi.mocked(fs.readdir).mockResolvedValue(["commit.md"] as never);
    vi.mocked(fs.pathExists).mockResolvedValue(true as never);
    vi.mocked(fs.readFile).mockImplementation(async (filePath: unknown) => {
      if (String(filePath).includes(MOCK_OUTPUT_PATH)) {
        return existingContent;
      }
      return newContent;
    });

    const conflicts = await checkForConflicts(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
    );

    expect(conflicts).toHaveLength(1);
    expect(conflicts[0]).toEqual({
      filename: "commit.md",
      existingContent,
      newContent,
    });
  });

  it("should detect conflict with prefixed filename when user chose a prefix", async () => {
    const existingContent = "# My custom red command";
    const newContent = "# Standard red phase";

    vi.mocked(fs.readdir).mockResolvedValue(["red.md"] as never);
    vi.mocked(fs.pathExists).mockImplementation(async (filePath: unknown) => {
      return String(filePath).includes("my-red.md");
    });
    vi.mocked(fs.readFile).mockImplementation(async (filePath: unknown) => {
      if (String(filePath).includes("my-red.md")) {
        return existingContent;
      }
      return newContent;
    });

    const conflicts = await checkForConflicts(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      "project",
      { commandPrefix: "my-" },
    );

    expect(conflicts).toHaveLength(1);
    expect(conflicts[0]).toEqual({
      filename: "my-red.md",
      existingContent,
      newContent,
    });
  });
});

describe("checkExistingFiles", () => {
  const MOCK_OUTPUT_PATH = "/mock/output/path";

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should return existing file with isIdentical flag when content matches", async () => {
    const sameContent = "# Same content";

    vi.mocked(fs.readdir).mockResolvedValue(["red.md"] as never);
    vi.mocked(fs.pathExists).mockResolvedValue(true as never);
    vi.mocked(fs.readFile).mockResolvedValue(sameContent as never);

    const { checkExistingFiles } = await import("./cli-generator.js");
    const files = await checkExistingFiles(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
    );

    expect(files).toHaveLength(1);
    expect(files[0]).toEqual({
      filename: "red.md",
      existingContent: sameContent,
      newContent: sameContent,
      isIdentical: true,
    });
  });

  it("should only check files specified in commands option", async () => {
    const existingContent = "# Existing";
    const newContent = "# New";

    // Source has 3 files
    vi.mocked(fs.readdir).mockResolvedValue([
      "red.md",
      "green.md",
      "add-command.md",
    ] as never);
    // All 3 exist in destination
    vi.mocked(fs.pathExists).mockResolvedValue(true as never);
    vi.mocked(fs.readFile).mockImplementation(async (filePath: unknown) => {
      if (String(filePath).includes(MOCK_OUTPUT_PATH)) {
        return existingContent;
      }
      return newContent;
    });

    const { checkExistingFiles } = await import("./cli-generator.js");
    // User only selected red.md - should only check that file
    const files = await checkExistingFiles(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      undefined,
      { commands: ["red.md"] },
    );

    // Should only return red.md, not green.md or add-command.md
    expect(files).toHaveLength(1);
    expect(files[0].filename).toBe("red.md");
  });

  it("should include allowedTools in newContent when command has matching _requested-tools", async () => {
    const sourceContent = "---\ndescription: Code review\n---\n# Code Review";
    const existingWithAllowedTools =
      "---\nallowed-tools: Bash(git diff:*)\ndescription: Code review\n---\n# Code Review";
    const mockMetadata = {
      "code-review.md": {
        description: "Code review",
        category: "Workflow",
        order: 1,
        "_requested-tools": ["Bash(git diff:*)", "Bash(git status:*)"],
      },
    };

    vi.mocked(fs.readdir).mockResolvedValue(["code-review.md"] as never);
    vi.mocked(fs.pathExists).mockResolvedValue(true as never);
    vi.mocked(fs.readFile).mockImplementation(async (filePath: unknown) => {
      if (String(filePath).includes("commands-metadata.json")) {
        return JSON.stringify(mockMetadata);
      }
      if (String(filePath).includes(MOCK_OUTPUT_PATH)) {
        return existingWithAllowedTools;
      }
      return sourceContent;
    });

    const { checkExistingFiles } = await import("./cli-generator.js");
    const files = await checkExistingFiles(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      undefined,
      { allowedTools: ["Bash(git diff:*)"] },
    );

    expect(files).toHaveLength(1);
    // newContent should include allowedTools header (command has _requested-tools)
    expect(files[0].newContent).toContain("allowed-tools: Bash(git diff:*)");
    // With allowedTools applied, content should match
    expect(files[0].isIdentical).toBe(true);
  });

  it("should NOT include allowedTools in newContent when command has no _requested-tools", async () => {
    const sourceContent = "---\ndescription: Red phase\n---\n# Red";
    const mockMetadata = {
      "red.md": {
        description: "Red phase",
        category: "TDD",
        order: 1,
        // No _requested-tools!
      },
    };

    vi.mocked(fs.readdir).mockResolvedValue(["red.md"] as never);
    vi.mocked(fs.pathExists).mockResolvedValue(true as never);
    vi.mocked(fs.readFile).mockImplementation(async (filePath: unknown) => {
      if (String(filePath).includes("commands-metadata.json")) {
        return JSON.stringify(mockMetadata);
      }
      if (String(filePath).includes(MOCK_OUTPUT_PATH)) {
        return sourceContent;
      }
      return sourceContent;
    });

    const { checkExistingFiles } = await import("./cli-generator.js");
    const files = await checkExistingFiles(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      undefined,
      { allowedTools: ["Bash(pnpm test:*)"] },
    );

    expect(files).toHaveLength(1);
    // newContent should NOT include allowedTools (command has no _requested-tools)
    expect(files[0].newContent).not.toContain("allowed-tools:");
  });
});

describe("getCommandsGroupedByCategory", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should return categories in defined order with Test-Driven Development first and Ship / Show / Ask last", async () => {
    const mockMetadata = {
      "ship.md": {
        description: "Ship",
        category: "Ship / Show / Ask",
        order: 1,
      },
      "red.md": {
        description: "Red",
        category: "Test-Driven Development",
        order: 1,
      },
      "commit.md": {
        description: "Commit",
        category: "Workflow",
        order: 1,
      },
      "plan.md": {
        description: "Plan",
        category: "Planning",
        order: 1,
      },
    };

    vi.mocked(fs.readFile).mockResolvedValue(
      JSON.stringify(mockMetadata) as never,
    );

    const { getCommandsGroupedByCategory, VARIANTS } =
      await import("./cli-generator.js");
    const grouped = await getCommandsGroupedByCategory(VARIANTS.WITH_BEADS);

    const categoryOrder = Object.keys(grouped);
    expect(categoryOrder[0]).toBe("Test-Driven Development");
    expect(categoryOrder[categoryOrder.length - 1]).toBe("Ship / Show / Ask");
  });

  it("should include hint from _hint property in command options", async () => {
    const mockMetadata = {
      "red.md": {
        description: "Execute Red Phase - write ONE failing test",
        hint: "Write failing test",
        category: "Test-Driven Development",
        order: 2,
      },
    };

    vi.mocked(fs.readFile).mockResolvedValue(
      JSON.stringify(mockMetadata) as never,
    );

    const { getCommandsGroupedByCategory, VARIANTS } =
      await import("./cli-generator.js");
    const grouped = await getCommandsGroupedByCategory(VARIANTS.WITH_BEADS);

    expect(grouped["Test-Driven Development"][0]).toMatchObject({
      value: "red.md",
      label: "red.md",
      hint: "Write failing test",
    });
  });
});

describe("generateToDirectory with allowedTools", () => {
  const MOCK_OUTPUT_PATH = "/mock/output/path";

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should accept allowedTools option", async () => {
    vi.mocked(fs.readdir).mockResolvedValue(["red.md"] as never);
    vi.mocked(fs.pathExists).mockResolvedValue(false as never);

    const result = await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
      { allowedTools: ["Bash(git diff:*)", "Bash(git status:*)"] },
    );

    expect(result.success).toBe(true);
  });

  it("should inject allowed-tools into command frontmatter when command has _requested-tools", async () => {
    const commandContent = `---
description: Code review
---

# Code Review`;
    const mockMetadata = {
      "code-review.md": {
        description: "Code review",
        category: "Workflow",
        order: 1,
        "_requested-tools": ["Bash(git diff:*)", "Bash(git status:*)"],
      },
    };

    vi.mocked(fs.readdir).mockResolvedValue(["code-review.md"] as never);
    vi.mocked(fs.pathExists).mockResolvedValue(false as never);
    vi.mocked(fs.readFile).mockImplementation(async (filePath: unknown) => {
      if (String(filePath).includes("commands-metadata.json")) {
        return JSON.stringify(mockMetadata);
      }
      return commandContent;
    });

    await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
      {
        allowedTools: ["Bash(git diff:*)", "Bash(git status:*)"],
      },
    );

    expect(fs.writeFile).toHaveBeenCalledWith(
      expect.stringContaining("code-review.md"),
      expect.stringContaining(
        "allowed-tools: Bash(git diff:*), Bash(git status:*)",
      ),
    );
  });

  it("should NOT inject allowed-tools into command without _requested-tools", async () => {
    const commandContent = `---
description: Red phase
---

# Red Phase`;
    const mockMetadata = {
      "red.md": {
        description: "Red phase",
        category: "TDD",
        order: 1,
        // No _requested-tools!
      },
    };

    vi.mocked(fs.readdir).mockResolvedValue(["red.md"] as never);
    vi.mocked(fs.pathExists).mockResolvedValue(false as never);
    vi.mocked(fs.readFile).mockImplementation(async (filePath: unknown) => {
      if (String(filePath).includes("commands-metadata.json")) {
        return JSON.stringify(mockMetadata);
      }
      return commandContent;
    });

    await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
      {
        allowedTools: ["Bash(git diff:*)", "Bash(git status:*)"],
      },
    );

    // Should NOT write to red.md since it has no _requested-tools
    expect(fs.writeFile).not.toHaveBeenCalledWith(
      expect.stringContaining("red.md"),
      expect.anything(),
    );
  });
});

describe("generateToDirectory with skipFiles", () => {
  const MOCK_OUTPUT_PATH = "/mock/output/path";

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should not copy files listed in skipFiles", async () => {
    vi.mocked(fs.readdir).mockResolvedValue([
      "red.md",
      "green.md",
      "commit.md",
    ] as never);
    vi.mocked(fs.pathExists).mockResolvedValue(false as never);

    await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
      { skipFiles: ["commit.md"] },
    );

    expect(fs.copy).toHaveBeenCalledTimes(2);
    expect(fs.copy).toHaveBeenCalledWith(
      expect.stringContaining("red.md"),
      expect.stringContaining("red.md"),
    );
    expect(fs.copy).toHaveBeenCalledWith(
      expect.stringContaining("green.md"),
      expect.stringContaining("green.md"),
    );
    expect(fs.copy).not.toHaveBeenCalledWith(
      expect.stringContaining("commit.md"),
      expect.anything(),
    );
  });

  it("should copy files directly to prefixed paths when skipFiles is empty and prefix is used", async () => {
    vi.mocked(fs.readdir).mockResolvedValue([
      "red.md",
      "green.md",
      "commit.md",
    ] as never);
    vi.mocked(fs.pathExists).mockResolvedValue(false as never);

    // This simulates user selecting "Yes" or "Overwrite all" for all conflicts
    // with a prefix - skipFiles should be empty, all files should be copied
    await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
      { commandPrefix: "my-", skipFiles: [] },
    );

    // All 3 files should be copied directly to prefixed paths
    expect(fs.copy).toHaveBeenCalledTimes(3);
    expect(fs.copy).toHaveBeenCalledWith(
      expect.stringContaining("red.md"),
      expect.stringContaining("my-red.md"),
    );
    expect(fs.copy).toHaveBeenCalledWith(
      expect.stringContaining("green.md"),
      expect.stringContaining("my-green.md"),
    );
    expect(fs.copy).toHaveBeenCalledWith(
      expect.stringContaining("commit.md"),
      expect.stringContaining("my-commit.md"),
    );
  });

  it("should skip files when skipFiles contains prefixed names from conflict resolver", async () => {
    vi.mocked(fs.readdir).mockResolvedValue([
      "red.md",
      "green.md",
      "commit.md",
    ] as never);
    vi.mocked(fs.pathExists).mockResolvedValue(false as never);

    // Simulates the actual CLI flow with prefix:
    // 1. User runs CLI with prefix "my-"
    // 2. checkExistingFiles finds existing "my-commit.md" and returns { filename: "my-commit.md", ... }
    // 3. User says "No" to skip that file (or file is identical)
    // 4. CLI adds "my-commit.md" to skipFiles
    // 5. generateToDirectory should NOT copy "commit.md" (the source file)
    await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
      { commandPrefix: "my-", skipFiles: ["my-commit.md"] },
    );

    // commit.md should NOT be copied because "my-commit.md" is in skipFiles
    expect(fs.copy).not.toHaveBeenCalledWith(
      expect.stringContaining("commit.md"),
      expect.anything(),
    );
  });

  it("should copy directly to prefixed path to enable overwriting existing files", async () => {
    vi.mocked(fs.readdir).mockResolvedValue(["add-command.md"] as never);
    vi.mocked(fs.pathExists).mockResolvedValue(false as never);

    // Simulates overwriting an existing prefixed file:
    // 1. User has existing "my-add-command.md" with different content
    // 2. User selects "Yes" or "Overwrite all"
    // 3. skipFiles is empty (file should be overwritten)
    // 4. File should be copied directly to "my-add-command.md" (not copy then rename)
    // 5. fs.copy with default overwrite:true handles overwriting existing files
    await generateToDirectory(
      MOCK_OUTPUT_PATH,
      VARIANTS.WITH_BEADS,
      SCOPES.PROJECT,
      { commandPrefix: "my-", skipFiles: [] },
    );

    // Should copy directly to the prefixed destination path
    expect(fs.copy).toHaveBeenCalledWith(
      expect.stringContaining("add-command.md"),
      expect.stringContaining("my-add-command.md"),
    );
  });
});

describe("getRequestedToolsOptions", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("should extract unique _requested-tools from commands metadata", async () => {
    const mockMetadata = {
      "red.md": {
        description: "Red phase",
        category: "TDD",
        order: 1,
        "_requested-tools": ["Bash(git diff:*)", "Bash(git status:*)"],
      },
      "code-review.md": {
        description: "Code review",
        category: "Workflow",
        order: 2,
        "_requested-tools": ["Bash(git diff:*)", "Bash(git log:*)"],
      },
      "commit.md": {
        description: "Commit",
        category: "Workflow",
        order: 3,
      },
    };

    vi.mocked(fs.readFile).mockResolvedValue(
      JSON.stringify(mockMetadata) as never,
    );

    const options = await getRequestedToolsOptions(VARIANTS.WITH_BEADS);

    expect(options).toEqual([
      {
        value: "Bash(git diff:*)",
        label: "git diff",
        hint: "/red, /code-review",
      },
      { value: "Bash(git status:*)", label: "git status", hint: "/red" },
      { value: "Bash(git log:*)", label: "git log", hint: "/code-review" },
    ]);
  });

  it("should include hint showing which commands use each tool", async () => {
    const mockMetadata = {
      "red.md": {
        description: "Red phase",
        category: "TDD",
        order: 1,
        "_requested-tools": ["Bash(git diff:*)", "Bash(git status:*)"],
      },
      "code-review.md": {
        description: "Code review",
        category: "Workflow",
        order: 2,
        "_requested-tools": ["Bash(git diff:*)", "Bash(git log:*)"],
      },
      "green.md": {
        description: "Green phase",
        category: "TDD",
        order: 2,
        "_requested-tools": ["Bash(git diff:*)"],
      },
      "refactor.md": {
        description: "Refactor phase",
        category: "TDD",
        order: 3,
        "_requested-tools": ["Bash(git diff:*)"],
      },
      "cycle.md": {
        description: "Full cycle",
        category: "TDD",
        order: 4,
        "_requested-tools": ["Bash(git diff:*)"],
      },
    };

    vi.mocked(fs.readFile).mockResolvedValue(
      JSON.stringify(mockMetadata) as never,
    );

    const options = await getRequestedToolsOptions(VARIANTS.WITH_BEADS);

    const gitDiffOption = options.find((o) => o.value === "Bash(git diff:*)");
    const gitStatusOption = options.find(
      (o) => o.value === "Bash(git status:*)",
    );
    const gitLogOption = options.find((o) => o.value === "Bash(git log:*)");

    // Tool used by 5 commands: show first 2, then "and 3 others"
    expect(gitDiffOption?.hint).toBe("/red, /code-review, and 3 others");
    // Tool used by 1 command: just show the command
    expect(gitStatusOption?.hint).toBe("/red");
    // Tool used by 1 command: just show the command
    expect(gitLogOption?.hint).toBe("/code-review");
  });
});
