import { describe, it, expect, beforeEach, afterEach } from "vitest";
import fs from "fs-extra";
import path from "path";
import os from "os";
import { execSync } from "child_process";
import { generateToDirectory, VARIANTS } from "../cli-generator";

const PROJECT_ROOT = path.join(import.meta.dirname, "../..");

/**
 * Execute a function with a temporary working directory, restoring original cwd afterward.
 */
async function withCwd<T>(dir: string, fn: () => Promise<T>): Promise<T> {
  const originalCwd = process.cwd();
  process.chdir(dir);
  try {
    return await fn();
  } finally {
    process.chdir(originalCwd);
  }
}

describe("Template Interpolation E2E", () => {
  let tempDir: string;

  beforeEach(async () => {
    tempDir = await fs.mkdtemp(
      path.join(os.tmpdir(), "claude-instructions-test-"),
    );
  });

  afterEach(async () => {
    if (tempDir && (await fs.pathExists(tempDir))) {
      await fs.remove(tempDir);
    }
  });

  it("should interpolate CLAUDE.md template content into generated commands", async () => {
    // Arrange: Create CLAUDE.md with template content in temp directory
    const customInstructions =
      "## Custom Project Rules\n\nAlways use TypeScript strict mode.";
    const claudeMdContent = `# Project Instructions

Some general instructions here.

<claude-commands-template>
${customInstructions}
</claude-commands-template>
`;
    await fs.writeFile(path.join(tempDir, "CLAUDE.md"), claudeMdContent);

    await withCwd(tempDir, async () => {
      const outputDir = path.join(tempDir, ".claude", "commands");

      // Act: Generate commands to output directory
      const result = await generateToDirectory(
        outputDir,
        VARIANTS.WITHOUT_BEADS,
      );

      // Assert: Template was injected
      expect(result.templateInjected).toBe(true);

      // Assert: At least one command file exists
      const files = await fs.readdir(outputDir);
      const mdFiles = files.filter((f) => f.endsWith(".md"));
      expect(mdFiles.length).toBeGreaterThan(0);

      // Assert: Generated command contains the custom instructions
      const commitMdPath = path.join(outputDir, "commit.md");
      const commitContent = await fs.readFile(commitMdPath, "utf-8");
      expect(commitContent).toContain(customInstructions);
    });
  });

  it("should fallback to AGENTS.md when CLAUDE.md does not exist", async () => {
    // Arrange: Create AGENTS.md (not CLAUDE.md) with template content
    const customInstructions =
      "## Agent-Specific Rules\n\nUse functional programming patterns.";
    const agentsMdContent = `# Agent Instructions

Configuration for agents.

<claude-commands-template>
${customInstructions}
</claude-commands-template>
`;
    await fs.writeFile(path.join(tempDir, "AGENTS.md"), agentsMdContent);

    await withCwd(tempDir, async () => {
      const outputDir = path.join(tempDir, ".claude", "commands");

      // Act: Generate commands
      const result = await generateToDirectory(
        outputDir,
        VARIANTS.WITHOUT_BEADS,
      );

      // Assert: Template was injected from AGENTS.md
      expect(result.templateInjected).toBe(true);

      // Assert: Generated command contains the custom instructions from AGENTS.md
      const commitMdPath = path.join(outputDir, "commit.md");
      const commitContent = await fs.readFile(commitMdPath, "utf-8");
      expect(commitContent).toContain(customInstructions);
    });
  });

  it("should only inject template into specified commands when commands attribute is used", async () => {
    // Arrange: Create CLAUDE.md with command-specific template
    const commitOnlyInstructions =
      "## Commit-Specific Rules\n\nAlways sign commits.";
    const claudeMdContent = `# Project Instructions

<claude-commands-template commands="commit">
${commitOnlyInstructions}
</claude-commands-template>
`;
    await fs.writeFile(path.join(tempDir, "CLAUDE.md"), claudeMdContent);

    await withCwd(tempDir, async () => {
      const outputDir = path.join(tempDir, ".claude", "commands");

      // Act: Generate commands
      const result = await generateToDirectory(
        outputDir,
        VARIANTS.WITHOUT_BEADS,
      );

      // Assert: Template was injected
      expect(result.templateInjected).toBe(true);

      // Assert: commit.md SHOULD contain the custom instructions
      const commitContent = await fs.readFile(
        path.join(outputDir, "commit.md"),
        "utf-8",
      );
      expect(commitContent).toContain(commitOnlyInstructions);

      // Assert: red.md should NOT contain the custom instructions (not in commands list)
      const redContent = await fs.readFile(
        path.join(outputDir, "red.md"),
        "utf-8",
      );
      expect(redContent).not.toContain(commitOnlyInstructions);
    });
  });

  it("should inject template into multiple specified commands", async () => {
    // Arrange: Create CLAUDE.md targeting two commands
    const tddInstructions = "## Cycle Rules\n\nRun tests after each change.";
    const claudeMdContent = `# Project Instructions

<claude-commands-template commands="red,green">
${tddInstructions}
</claude-commands-template>
`;
    await fs.writeFile(path.join(tempDir, "CLAUDE.md"), claudeMdContent);

    await withCwd(tempDir, async () => {
      const outputDir = path.join(tempDir, ".claude", "commands");

      // Act
      const result = await generateToDirectory(
        outputDir,
        VARIANTS.WITHOUT_BEADS,
      );

      // Assert: Template was injected
      expect(result.templateInjected).toBe(true);

      // Assert: red.md SHOULD contain the instructions
      const redContent = await fs.readFile(
        path.join(outputDir, "red.md"),
        "utf-8",
      );
      expect(redContent).toContain(tddInstructions);

      // Assert: green.md SHOULD contain the instructions
      const greenContent = await fs.readFile(
        path.join(outputDir, "green.md"),
        "utf-8",
      );
      expect(greenContent).toContain(tddInstructions);

      // Assert: commit.md should NOT contain the instructions
      const commitContent = await fs.readFile(
        path.join(outputDir, "commit.md"),
        "utf-8",
      );
      expect(commitContent).not.toContain(tddInstructions);
    });
  });

  it("should append content from multiple templates targeting the same command", async () => {
    // Arrange: Create CLAUDE.md with two templates both targeting commit
    const firstTemplate = "## General Rules\n\nUse conventional commits.";
    const secondTemplate = "## Security Rules\n\nNever commit secrets.";
    const claudeMdContent = `# Project Instructions

<claude-commands-template commands="commit">
${firstTemplate}
</claude-commands-template>

<claude-commands-template commands="commit">
${secondTemplate}
</claude-commands-template>
`;
    await fs.writeFile(path.join(tempDir, "CLAUDE.md"), claudeMdContent);

    await withCwd(tempDir, async () => {
      const outputDir = path.join(tempDir, ".claude", "commands");

      // Act
      const result = await generateToDirectory(
        outputDir,
        VARIANTS.WITHOUT_BEADS,
      );

      // Assert: Template was injected
      expect(result.templateInjected).toBe(true);

      // Assert: commit.md contains BOTH templates appended
      const commitContent = await fs.readFile(
        path.join(outputDir, "commit.md"),
        "utf-8",
      );
      expect(commitContent).toContain(firstTemplate);
      expect(commitContent).toContain(secondTemplate);
    });
  });

  it("should append content from three templates all targeting the same command", async () => {
    // Arrange: Create CLAUDE.md with three templates all targeting commit
    const firstTemplate = "## Style Guide\n\nUse imperative mood.";
    const secondTemplate = "## Scope Rules\n\nAlways include scope.";
    const thirdTemplate = "## Footer Rules\n\nInclude issue reference.";
    const claudeMdContent = `# Project Instructions

<claude-commands-template commands="commit">
${firstTemplate}
</claude-commands-template>

<claude-commands-template commands="commit">
${secondTemplate}
</claude-commands-template>

<claude-commands-template commands="commit">
${thirdTemplate}
</claude-commands-template>
`;
    await fs.writeFile(path.join(tempDir, "CLAUDE.md"), claudeMdContent);

    await withCwd(tempDir, async () => {
      const outputDir = path.join(tempDir, ".claude", "commands");

      // Act
      const result = await generateToDirectory(
        outputDir,
        VARIANTS.WITHOUT_BEADS,
      );

      // Assert: Template was injected
      expect(result.templateInjected).toBe(true);

      // Assert: commit.md contains ALL THREE templates appended
      const commitContent = await fs.readFile(
        path.join(outputDir, "commit.md"),
        "utf-8",
      );
      expect(commitContent).toContain(firstTemplate);
      expect(commitContent).toContain(secondTemplate);
      expect(commitContent).toContain(thirdTemplate);
    });
  });

  it("should not inject when CLAUDE.md exists but has no template tag", async () => {
    // Arrange: Create CLAUDE.md without <claude-commands-template> tag
    const claudeMdContent = `# Project Instructions

This is a project without any template blocks.

## Guidelines
- Use TypeScript
- Write tests
`;
    await fs.writeFile(path.join(tempDir, "CLAUDE.md"), claudeMdContent);

    await withCwd(tempDir, async () => {
      const outputDir = path.join(tempDir, ".claude", "commands");

      // Act
      const result = await generateToDirectory(
        outputDir,
        VARIANTS.WITHOUT_BEADS,
      );

      // Assert: Generation succeeded but no template was injected
      expect(result.success).toBe(true);
      expect(result.templateInjected).toBe(false);

      // Assert: Commands were generated
      const files = await fs.readdir(outputDir);
      expect(files.filter((f) => f.endsWith(".md")).length).toBeGreaterThan(0);
    });
  });
});

describe("Allowed Tools Conflict Detection E2E", () => {
  let tempDir: string;

  beforeEach(async () => {
    tempDir = await fs.mkdtemp(
      path.join(os.tmpdir(), "claude-instructions-allowed-tools-"),
    );
  });

  afterEach(async () => {
    if (tempDir && (await fs.pathExists(tempDir))) {
      await fs.remove(tempDir);
    }
  });

  it("should detect files as identical when re-generating with same allowed tools", async () => {
    const { checkExistingFiles } = await import("../cli-generator.js");
    const outputDir = path.join(tempDir, ".claude", "commands");
    // Use tools that code-review.md actually requests in _requested-tools
    const allowedTools = ["Bash(git diff:*)", "Bash(git status:*)"];

    // First generation with allowed tools - use code-review.md which has _requested-tools
    await generateToDirectory(outputDir, VARIANTS.WITHOUT_BEADS, undefined, {
      commands: ["code-review.md"],
      allowedTools,
    });

    // Verify file was created with allowed-tools header
    const firstContent = await fs.readFile(
      path.join(outputDir, "code-review.md"),
      "utf-8",
    );
    expect(firstContent).toContain(
      "allowed-tools: Bash(git diff:*), Bash(git status:*)",
    );

    // Check for conflicts with same allowed tools - should be identical
    const existingFiles = await checkExistingFiles(
      outputDir,
      VARIANTS.WITHOUT_BEADS,
      undefined,
      {
        commands: ["code-review.md"],
        allowedTools,
      },
    );

    expect(existingFiles).toHaveLength(1);
    expect(existingFiles[0].isIdentical).toBe(true);
  });

  it("should only inject allowed-tools into commands that requested them via _requested-tools", async () => {
    const outputDir = path.join(tempDir, ".claude", "commands");
    // These are tools that code-review.md requests in its _requested-tools
    const allowedTools = ["Bash(git diff:*)", "Bash(git status:*)"];

    // Generate both code-review.md (has _requested-tools) and red.md (no _requested-tools)
    await generateToDirectory(outputDir, VARIANTS.WITHOUT_BEADS, undefined, {
      commands: ["code-review.md", "red.md"],
      allowedTools,
    });

    // code-review.md SHOULD have allowed-tools (it has matching _requested-tools)
    const codeReviewContent = await fs.readFile(
      path.join(outputDir, "code-review.md"),
      "utf-8",
    );
    expect(codeReviewContent).toContain(
      "allowed-tools: Bash(git diff:*), Bash(git status:*)",
    );

    // red.md should NOT have allowed-tools (it has no _requested-tools)
    const redContent = await fs.readFile(
      path.join(outputDir, "red.md"),
      "utf-8",
    );
    expect(redContent).not.toContain("allowed-tools:");
  });
});

describe("Postinstall Workflow E2E", () => {
  let tempDir: string;

  beforeEach(async () => {
    tempDir = await fs.mkdtemp(
      path.join(os.tmpdir(), "claude-instructions-postinstall-"),
    );
  });

  afterEach(async () => {
    if (tempDir && (await fs.pathExists(tempDir))) {
      await fs.remove(tempDir);
    }
  });

  it(
    "should regenerate commands on postinstall when configured as dev dependency",
    { timeout: 60000 },
    async () => {
      // Pack the package to get a local tarball (avoids registry)
      execSync("pnpm pack --pack-destination " + tempDir, {
        cwd: PROJECT_ROOT,
        stdio: "pipe",
      });

      const files = await fs.readdir(tempDir);
      const tarball = files.find((f) => f.endsWith(".tgz"));
      expect(tarball).toBeDefined();

      // Create a minimal project with postinstall script
      const projectDir = path.join(tempDir, "test-project");
      await fs.mkdir(projectDir);

      const packageJson = {
        name: "test-project",
        version: "1.0.0",
        scripts: {
          postinstall:
            "npx @wbern/claude-instructions --variant=without-beads --scope=project --prefix= --skip-template-injection",
        },
        devDependencies: {
          "@wbern/claude-instructions": `file:${path.join(tempDir, tarball!)}`,
        },
      };
      await fs.writeJson(path.join(projectDir, "package.json"), packageJson);

      // Run pnpm install - this should trigger postinstall
      execSync("pnpm install", {
        cwd: projectDir,
        stdio: "pipe",
      });

      // Assert: Commands were generated in .claude/commands
      const commandsDir = path.join(projectDir, ".claude", "commands");
      expect(await fs.pathExists(commandsDir)).toBe(true);

      const commandFiles = await fs.readdir(commandsDir);
      const mdFiles = commandFiles.filter((f) => f.endsWith(".md"));
      expect(mdFiles.length).toBeGreaterThan(0);
      expect(mdFiles).toContain("commit.md");
    },
  );
});
