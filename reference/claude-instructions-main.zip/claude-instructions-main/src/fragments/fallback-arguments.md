(If there was no info above, fallback to the context of the conversation)
