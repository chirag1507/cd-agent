(If there was no info above, fallback to:
1. Context of the conversation, if there's an immediate thing
2. `bd ready` to see what to work on next and start from there)
