## Beads Integration

If Beads MCP is available, check for task tracking status and ask if the user wants to:
1. Review current task status
2. Update task states based on conversation progress
3. Include Beads context in the summary

Use AskUserQuestion to confirm Beads integration preferences.