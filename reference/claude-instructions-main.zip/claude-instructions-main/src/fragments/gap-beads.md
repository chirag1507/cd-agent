4. **Open issues** - Beads issues that are still open or in progress
