8. **Consistency check** - Look for inconsistent patterns, naming conventions, or structure across the codebase
