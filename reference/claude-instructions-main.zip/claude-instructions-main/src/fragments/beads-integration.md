### Beads Integration

Use Beads MCP to:
- Track work with `bd ready` to find next task
- Create issues with `bd create "description"`
- Track dependencies with `bd dep add`

See https://github.com/steveyegge/beads for more information.
